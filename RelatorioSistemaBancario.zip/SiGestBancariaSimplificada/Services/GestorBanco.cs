﻿using SiGestBancariaSimplificada.Interfaces;
using SiGestBancariaSimplificada.Exceptions;
using SiGestBancariaSimplificada.Models;
using SiGestBancariaSimplificada.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Services
{
    public class GestorBanco
    {

            private readonly IRepositorioConta _repositorio;

            public GestorBanco()
            {
                _repositorio = new ContaRepository();
            }

            public void CriarConta(Cliente titular, int senha, int chaveTransferencia, string tipoConta)
            {
                Conta novaConta;
                if (tipoConta.Equals("corrente", StringComparison.OrdinalIgnoreCase))
                    novaConta = new ContaCorrente(titular, senha, chaveTransferencia);
                else if (tipoConta.Equals("poupanca", StringComparison.OrdinalIgnoreCase))
                    novaConta = new ContaPoupanca(titular, senha, chaveTransferencia);
                else
                    throw new ArgumentException("Tipo de conta inválido. Use 'corrente' ou 'poupanca'.");

                _repositorio.Adicionar(novaConta);
                Console.WriteLine($"Conta {tipoConta} criada com sucesso! Número: {novaConta.NumeroConta}");
            }

            public Conta ObterContaPorNumero(int numero)
            {
                var conta = _repositorio.BuscarPorNumero(numero);
                if (conta == null) throw new ContaNaoEncontradaException($"Conta número {numero} não encontrada.");
                return conta;
            }

            public Conta ObterContaPorChave(int chave)
            {
                var conta = _repositorio.BuscarPorChaveTransferencia(chave);
                if (conta == null) throw new ContaNaoEncontradaException($"Nenhuma conta com a chave {chave}.");
                return conta;
            }

            public void TransferirEntreContas(Conta origem, int chaveDestino, double valor)
            {
                var destino = ObterContaPorChave(chaveDestino);
                origem.Transferir(destino, valor);
            }

            public List<Conta> ListarTodasContas() => _repositorio.ListarTodas();
        }

        // Excepção adicional para conta não encontrada (pode estar no namespace Exceptions)
        public class ContaNaoEncontradaException : Exception
        {
            public ContaNaoEncontradaException(string msg) : base(msg) { }
        }
}
