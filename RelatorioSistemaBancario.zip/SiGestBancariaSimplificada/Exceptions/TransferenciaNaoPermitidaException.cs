﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Exceptions
{
    public class TransferenciaNaoPermitidaException : Exception
    {
        public TransferenciaNaoPermitidaException(string mensagem) : base(mensagem) { }
        public TransferenciaNaoPermitidaException(string mensagem, Exception interna) : base(mensagem, interna) { }
    }

}

