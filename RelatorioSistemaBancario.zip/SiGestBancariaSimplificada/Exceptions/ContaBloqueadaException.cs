﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Exceptions
{
        public class ContaBloqueadaException : Exception
        {
            public ContaBloqueadaException(string mensagem) : base(mensagem) { }
            public ContaBloqueadaException(string mensagem, Exception interna) : base(mensagem, interna) { }
        }
}
