﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Exceptions
{
        public class SaldoInsuficienteException : Exception
        {
            public SaldoInsuficienteException(string mensagem) : base(mensagem) { }
            public SaldoInsuficienteException(string mensagem, Exception interna) : base(mensagem, interna) { }
        }
}
