﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Interfaces
{
    public interface IContaBancaria
    {
        void Depositar(double valor);
        void Sacar(double valor);
        void Transferir(IContaBancaria destino, double valor);
        void Bloquear();
        void Desbloquear();
        void MostrarInformacoes();
        string ObterResumo();
    }
}
