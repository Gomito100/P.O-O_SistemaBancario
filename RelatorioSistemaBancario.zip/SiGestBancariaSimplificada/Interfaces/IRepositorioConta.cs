﻿using SiGestBancariaSimplificada.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Interfaces
{
    public interface IRepositorioConta
    {
        void Adicionar(Conta conta);
        Conta BuscarPorNumero(int numeroConta);
        Conta BuscarPorChaveTransferencia(int chave);
        List<Conta> ListarTodas();
        void Actualizar(Conta conta);
    }
}
