﻿using SiGestBancariaSimplificada.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Models
{
    public class ContaCorrente : Conta
    {
        public double TaxaManutencao { get; private set; }

        public ContaCorrente(Cliente titular, int senha, int chaveTransferencia, double taxaManutencao = 5.0)
            : base(titular, senha, chaveTransferencia)
        {
            TaxaManutencao = taxaManutencao;
        }

        public void CobrarTaxaMensal()
        {
            if (Saldo >= TaxaManutencao)
                Sacar(TaxaManutencao);
            else
                throw new SaldoInsuficienteException($"Saldo insuficiente para cobrar taxa de manutenção ({TaxaManutencao:C2}).");
            RegistrarMovimento($"Taxa de manutenção ({TaxaManutencao:C2})", -TaxaManutencao);
        }

        public override string ObterResumo() => $"Conta Corrente {NumeroConta} - Saldo: {Saldo:C2} - Taxa: {TaxaManutencao:C2}";
    }
}
