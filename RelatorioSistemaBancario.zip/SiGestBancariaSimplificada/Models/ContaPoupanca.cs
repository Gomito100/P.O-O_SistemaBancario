﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Models
{
    public class ContaPoupanca : Conta
    {
        public double TaxaJurosAnual { get; private set; }

        public ContaPoupanca(Cliente titular, int senha, int chaveTransferencia, double taxaJurosAnual = 0.05)
            : base(titular, senha, chaveTransferencia)
        {
            TaxaJurosAnual = taxaJurosAnual;
        }

        public void AplicarRendimentoMensal()
        {
            double juros = Saldo * (TaxaJurosAnual / 12);
            if (juros > 0)
            {
                _saldo += juros;
                RegistrarMovimento($"Rendimento de poupança ({juros:C2})", juros);
            }
        }

        public override string ObterResumo() => $"Conta Poupança {NumeroConta} - Saldo: {Saldo:C2} - Juros anual: {TaxaJurosAnual:P}";
    }
}
