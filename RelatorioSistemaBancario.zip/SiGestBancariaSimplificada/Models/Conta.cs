﻿using SiGestBancariaSimplificada.Interfaces;
using SiGestBancariaSimplificada.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Models
{
    public class Conta : IContaBancaria
    {
        private static int _proximoNumero = 1000;
        public int NumeroConta { get; private set; }
        public int ChaveTransferencia { get; private set; }
        public Cliente Titular { get; private set; }
        protected double _saldo;
        public double Saldo => _saldo;
        public bool EstaBloqueada { get; private set; }
        private int _senha;
        protected List<Movimento> Historico { get; private set; }

        public Conta(Cliente titular, int senha, int chaveTransferencia)
        {
            NumeroConta = _proximoNumero++;
            Titular = titular;
            _senha = senha;
            ChaveTransferencia = chaveTransferencia;
            _saldo = 0;
            EstaBloqueada = false;
            Historico = new List<Movimento>();
            RegistrarMovimento("Conta criada", 0);
        }

        public bool VerificarSenha(int tentativa) => tentativa == _senha;

        protected void RegistrarMovimento(string descricao, double valor)
        {
            Historico.Add(new Movimento(descricao, valor, _saldo));
        }

        public virtual void Depositar(double valor)
        {
            if (EstaBloqueada) throw new ContaBloqueadaException("Conta bloqueada. Não é possível depositar.");
            if (valor <= 0) throw new ArgumentException("Valor de depósito deve ser positivo.");

            _saldo += valor;
            RegistrarMovimento($"Depósito de {valor:C2}", valor);
        }

        public virtual void Sacar(double valor)
        {
            if (EstaBloqueada) throw new ContaBloqueadaException("Conta bloqueada. Não é possível sacar.");
            if (valor <= 0) throw new ArgumentException("Valor de saque deve ser positivo.");
            if (valor > _saldo) throw new SaldoInsuficienteException($"Saldo insuficiente. Disponível: {_saldo:C2}");

            _saldo -= valor;
            RegistrarMovimento($"Saque de {valor:C2}", -valor);
        }

        public virtual void Transferir(IContaBancaria destino, double valor)
        {
            if (EstaBloqueada) throw new ContaBloqueadaException("Conta origem bloqueada.");
            if (valor <= 0) throw new ArgumentException("Valor de transferência deve ser positivo.");
            if (valor > _saldo) throw new SaldoInsuficienteException($"Saldo insuficiente para transferência. Disponível: {_saldo:C2}");

            // Tentar sacar da origem
            Sacar(valor);
            try
            {
                destino.Depositar(valor);
                RegistrarMovimento($"Transferência enviada para conta {((Conta)destino).NumeroConta} no valor de {valor:C2}", -valor);
            }
            catch (Exception ex)
            {
                // Reverter o saque se o depósito falhar
                _saldo += valor;
                throw new TransferenciaNaoPermitidaException($"Falha na transferência: {ex.Message}", ex);
            }
        }

        public void Bloquear()
        {
            if (!EstaBloqueada)
            {
                EstaBloqueada = true;
                RegistrarMovimento("Conta bloqueada", 0);
            }
        }

        public void Desbloquear()
        {
            if (EstaBloqueada)
            {
                EstaBloqueada = false;
                RegistrarMovimento("Conta desbloqueada", 0);
            }
        }

        public void MostrarInformacoes()
        {
            Console.WriteLine($"Número: {NumeroConta} | Titular: {Titular.Nome} | Saldo: {_saldo:C2} | Estado: {(EstaBloqueada ? "Bloqueada" : "Activa")}");
            Console.WriteLine($"Chave de transferência: {ChaveTransferencia}");
        }

        public virtual string ObterResumo()
        {
            return $"{NumeroConta} - {Titular?.Nome ?? "Sem Titular"} - {_saldo:C2}";
        }

        public List<Movimento> ObterHistorico() => new List<Movimento>(Historico);
    }
}
