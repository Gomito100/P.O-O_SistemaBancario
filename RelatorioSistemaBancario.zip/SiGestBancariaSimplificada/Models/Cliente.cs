﻿using SiGestBancariaSimplificada.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Models
{
    public class Cliente
    {
        public string Nome { get; private set; }
        public string Nif { get; private set; }

        public Cliente(string nome, string nif)
        {
            if (!Validador.ValidarNome(nome))
                throw new ArgumentException("Nome inválido. Use apenas letras e espaços.");
            if (!Validador.ValidarNif(nif))
                throw new ArgumentException("NIF inválido. Deve ter 14 dígitos (ex: 007448620UE047).");

            Nome = nome.Trim();
            Nif = nif.Trim();
        }
    }
}
