﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Models
{
    public class Movimento
    {
        public DateTime Data { get; private set; }
        public string Descricao { get; private set; }
        public double Valor { get; private set; }
        public double SaldoAposMovimento { get; private set; }

        public Movimento(string descricao, double valor, double saldoApos)
        {
            Data = DateTime.Now;
            Descricao = descricao;
            Valor = valor;
            SaldoAposMovimento = saldoApos;
        }

        public override string ToString() => $"{Data:dd/MM/yyyy HH:mm} - {Descricao}: {Valor:C2} - Saldo: {SaldoAposMovimento:C2}";
    }
}
