﻿using SiGestBancariaSimplificada.Interfaces;
using SiGestBancariaSimplificada.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Repositories
{
    public class ContaRepository : IRepositorioConta
    {
        private readonly List<Conta> _contas = new List<Conta>();

        public void Adicionar(Conta conta)
        {
            if (conta == null)
                throw new System.ArgumentException("Conta não pode ser nula.");
            _contas.Add(conta);
        }

        public Conta BuscarPorNumero(int numeroConta)
        {
            return _contas.FirstOrDefault(c => c.NumeroConta == numeroConta);
        }

        public Conta BuscarPorChaveTransferencia(int chave)
        {
            return _contas.FirstOrDefault(c => c.ChaveTransferencia == chave);
        }

        public List<Conta> ListarTodas()
        {
            return new List<Conta>(_contas);
        }

        public void Actualizar(Conta conta)
        {
            int index = _contas.FindIndex(c => c.NumeroConta == conta.NumeroConta);
            if (index >= 0)
                _contas[index] = conta;
        }
    }
}
