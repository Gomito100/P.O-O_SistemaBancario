﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SiGestBancariaSimplificada.Utils
{
    public class Validador
    {
        public static bool ValidarNome(string nome)
        {
            if (string.IsNullOrWhiteSpace(nome)) return false;
            return nome.All(c => char.IsLetter(c) || char.IsWhiteSpace(c));
        }

        public static bool ValidarNif(string nif)
        {
            if (string.IsNullOrWhiteSpace(nif)) return false;
            nif = nif.Trim();
            return (nif.Length == 14 || nif.Length == 14) && nif.All(char.IsDigit);
        }

        public static bool ValidarSenha(string senha)
        {
            return !string.IsNullOrWhiteSpace(senha) && senha.Length == 4 && senha.All(char.IsDigit);
        }
    }
}
