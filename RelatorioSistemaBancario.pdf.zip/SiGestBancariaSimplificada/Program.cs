﻿using SiGestBancariaSimplificada.Exceptions;
using SiGestBancariaSimplificada.Models;
using SiGestBancariaSimplificada.Services;
using SiGestBancariaSimplificada.Utils;

namespace SiGestBancariaSimplificada
{
    internal class Program
    {
        static GestorBanco banco = new GestorBanco();
        static Conta contaLogada = null;

        static void Main(string[] args)
        {
            // Dados iniciais para teste
            InicializarDados();

            bool continuar = true;
            while (continuar)
            {
                if (contaLogada == null)
                    continuar = MenuPrincipal();
                else
                    continuar = MenuCliente();
            }
        }

        static void InicializarDados()
        {
            try
            {
                var cliente1 = new Cliente("Pedro Viegas Armando", "123456789");
                var cliente2 = new Cliente("Isabel Rocha", "987654321");
                banco.CriarConta(cliente1, 1234, 23, "corrente");
                banco.CriarConta(cliente2, 2222, 44, "poupanca");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro na inicialização: {ex.Message}");
            }
        }

        static bool MenuPrincipal()
        {
            Console.Clear();
            Console.WriteLine("===== SISTEMA BANCÁRIO =====");
            Console.WriteLine("1 - Criar nova conta");
            Console.WriteLine("2 - Aceder a conta existente");
            Console.WriteLine("3 - Listar todas as contas (simplificado)");
            Console.WriteLine("0 - Sair");
            Console.Write("Opção: ");
            string opcao = Console.ReadLine();

            switch (opcao)
            {
                case "1": CriarNovaConta(); return true;
                case "2": AcederConta(); return true;
                case "3": ListarContas(); return true;
                case "0": return false;
                default: Console.WriteLine("Opção inválida!"); Thread.Sleep(1000); return true;
            }
        }

        static void CriarNovaConta()
        {
            Console.Clear();
            Console.WriteLine("--- Criar nova conta ---");
            string nome;
            do
            {
                Console.Write("Nome completo (apenas letras): ");
                nome = Console.ReadLine();
                if (!Validador.ValidarNome(nome))
                    Console.WriteLine("Nome inválido! Use apenas letras e espaços.");
            } while (!Validador.ValidarNome(nome));

            string nif;
            do
            {
                Console.Write("NIF (14 dígitos): ");
                nif = Console.ReadLine();
                if (!Validador.ValidarNif(nif))
                    Console.WriteLine("NIF inválido! Deve ter 14 dígitos.");
            } while (!Validador.ValidarNif(nif));

            string senhaStr;
            int senha;
            do
            {
                Console.Write("Senha (4 dígitos): ");
                senhaStr = Console.ReadLine();
                if (!Validador.ValidarSenha(senhaStr))
                    Console.WriteLine("Senha deve ter 4 dígitos numéricos.");
            } while (!Validador.ValidarSenha(senhaStr));
            senha = int.Parse(senhaStr);

            Console.Write("Chave de transferência (número inteiro): ");
            int chave = int.Parse(Console.ReadLine());

            string tipo;
            do
            {
                Console.Write("Tipo de conta (corrente/poupanca): ");
                tipo = Console.ReadLine().ToLower();
            } while (tipo != "corrente" && tipo != "poupanca");

            var cliente = new Cliente(nome, nif);
            try
            {
                banco.CriarConta(cliente, senha, chave, tipo);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
            Console.WriteLine("Pressione ENTER para continuar...");
            Console.ReadLine();
        }

        static void AcederConta()
        {
            Console.Clear();
            Console.Write("Número da conta: ");
            if (!int.TryParse(Console.ReadLine(), out int num))
            {
                Console.WriteLine("Número inválido.");
                Console.ReadLine();
                return;
            }
            Console.Write("Senha: ");
            if (!int.TryParse(Console.ReadLine(), out int senha))
            {
                Console.WriteLine("Senha inválida.");
                Console.ReadLine();
                return;
            }

            try
            {
                var conta = banco.ObterContaPorNumero(num);
                if (conta.VerificarSenha(senha))
                {
                    contaLogada = conta;
                    Console.WriteLine($"Bem-vindo, {conta.Titular.Nome}!");
                    Thread.Sleep(1000);
                }
                else
                {
                    Console.WriteLine("Senha incorreta.");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
                Console.ReadLine();
            }
        }

        static void ListarContas()
        {
            Console.Clear();
            var contas = banco.ListarTodasContas();
            if (contas.Count == 0)
                Console.WriteLine("Nenhuma conta registada.");
            else
                foreach (var c in contas)
                    Console.WriteLine($"Nº {c.NumeroConta} | {c.Titular.Nome} | Saldo: {c.Saldo:C2} | Tipo: {c.GetType().Name}");
            Console.WriteLine("Pressione ENTER para voltar.");
            Console.ReadLine();
        }

        static bool MenuCliente()
        {
            Console.Clear();
            Console.WriteLine($"===== Bem-vindo, {contaLogada.Titular.Nome} =====");
            Console.WriteLine("1 - Depositar");
            Console.WriteLine("2 - Sacar");
            Console.WriteLine("3 - Transferir");
            Console.WriteLine("4 - Ver extracto (histórico)");
            Console.WriteLine("5 - Ver informações da conta");
            Console.WriteLine("6 - Bloquear/Desbloquear conta");
            Console.WriteLine("7 - Aplicar rendimento (poupança)");
            Console.WriteLine("8 - Sair da conta");
            Console.Write("Opção: ");
            string opcao = Console.ReadLine();

            try
            {
                switch (opcao)
                {
                    case "1": Depositar(); break;
                    case "2": Sacar(); break;
                    case "3": Transferir(); break;
                    case "4": MostrarExtracto(); break;
                    case "5": contaLogada.MostrarInformacoes(); break;
                    case "6": AlternarBloqueio(); break;
                    case "7": AplicarRendimento(); break;
                    case "8": contaLogada = null; Console.WriteLine("A sair da conta..."); break;
                    default: Console.WriteLine("Opção inválida!"); break;
                }
            }
            catch (SaldoInsuficienteException ex) { Console.WriteLine($"Erro: {ex.Message}"); }
            catch (ContaBloqueadaException ex) { Console.WriteLine($"Erro: {ex.Message}"); }
            catch (TransferenciaNaoPermitidaException ex) { Console.WriteLine($"Erro: {ex.Message}"); }
            catch (Exception ex) { Console.WriteLine($"Erro inesperado: {ex.Message}"); }

            if (opcao != "8")
            {
                Console.WriteLine("\nPressione ENTER para continuar...");
                Console.ReadLine();
            }
            return true;
        }

        static void Depositar()
        {
            Console.Write("Valor a depositar (Kz): ");
            double valor = double.Parse(Console.ReadLine());
            contaLogada.Depositar(valor);
            Console.WriteLine("Depósito efectuado com sucesso!");
        }

        static void Sacar()
        {
            Console.Write("Valor a sacar (Kz): ");
            double valor = double.Parse(Console.ReadLine());
            contaLogada.Sacar(valor);
            Console.WriteLine("Saque efectuado!");
        }

        static void Transferir()
        {
            Console.Write("Chave de transferência do destinatário: ");
            int chave = int.Parse(Console.ReadLine());
            Console.Write("Valor a transferir (Kz): ");
            double valor = double.Parse(Console.ReadLine());
            banco.TransferirEntreContas(contaLogada, chave, valor);
            Console.WriteLine("Transferência realizada com sucesso!");
        }

        static void MostrarExtracto()
        {
            var historico = contaLogada.ObterHistorico();
            if (historico.Count == 0)
                Console.WriteLine("Nenhum movimento registado.");
            else
                foreach (var mov in historico)
                    Console.WriteLine(mov);
        }

        static void AlternarBloqueio()
        {
            if (contaLogada.EstaBloqueada)
            {
                contaLogada.Desbloquear();
                Console.WriteLine("Conta desbloqueada.");
            }
            else
            {
                contaLogada.Bloquear();
                Console.WriteLine("Conta bloqueada.");
            }
        }

        static void AplicarRendimento()
        {
            if (contaLogada is ContaPoupanca poupanca)
            {
                poupanca.AplicarRendimentoMensal();
                Console.WriteLine("Rendimento aplicado à conta poupança.");
            }
            else
            {
                Console.WriteLine("Apenas contas poupança têm rendimento mensal.");
            }
        }
    }
}
